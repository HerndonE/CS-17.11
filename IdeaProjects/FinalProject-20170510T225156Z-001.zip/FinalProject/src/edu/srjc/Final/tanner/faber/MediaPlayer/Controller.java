/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.srjc.Final.tanner.faber.MediaPlayer;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Slider;
import javafx.scene.media.MediaView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


public class Controller implements Initializable
{

    @FXML
    MediaView mediaView;
    private MediaPlayer mediaPlayer;
    private Media media;
    @FXML
    Slider Volume;


    @FXML
    private void handlePlayButton(ActionEvent event)
    {
        System.out.println("You clicked me!");
        mediaPlayer.play();
        mediaPlayer.setRate(1);
    }

    @FXML
    private void handlePauseButton(ActionEvent event)
    {
        System.out.println("You clicked me!");
        mediaPlayer.pause();
        mediaPlayer.setRate(1);
    }

    @FXML
    private void handleBackButton(ActionEvent event)
    {
        System.out.println("You clicked me!");
        mediaPlayer.seek(mediaPlayer.getCurrentTime().subtract(javafx.util.Duration.seconds(15)));
        mediaPlayer.setRate(1);
    }

    @FXML
    private void handleForwardButton(ActionEvent event)
    {
        System.out.println("You clicked me!");
        mediaPlayer.seek(mediaPlayer.getCurrentTime().add(javafx.util.Duration.seconds(15)));
        mediaPlayer.setRate(1);
    }

    @FXML
    private void handleFastForwardButton(ActionEvent event)
    {
        System.out.println("You clicked me!");
        mediaPlayer.setRate(2);
    }

    @FXML
    private void handleReloadButton(ActionEvent event)
    {
        System.out.println("You clicked me!");
        mediaPlayer.seek(mediaPlayer.getStartTime());
        mediaPlayer.pause();
        mediaPlayer.setRate(1);
    }

    @FXML
    private void handleEndButton(ActionEvent event)
    {
        System.out.println("You clicked me!");
        mediaPlayer.seek(mediaPlayer.getStopTime());
        mediaPlayer.pause();
        mediaPlayer.setRate(1);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        //load file into MediaView
        String path = "It's Over 9000!! [1080p HD].mp4";
        media = new Media(new File(path).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        mediaView.setMediaPlayer(mediaPlayer);

        //Create listener for volume slider
        Volume.setValue(mediaPlayer.getVolume()*100);
        Volume.valueProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
                mediaPlayer.setVolume(Volume.getValue()/100);
            }
        });

        //Todo
        //Label that displays the current Time


        //Bind MediaView to screen size
        DoubleProperty width = mediaView.fitWidthProperty();
        DoubleProperty hieght = mediaView.fitHeightProperty();
        width.bind(Bindings.selectDouble(mediaView.sceneProperty(),"width"));
        hieght.bind(Bindings.selectDouble(mediaView.sceneProperty(),"height"));

    }

}
